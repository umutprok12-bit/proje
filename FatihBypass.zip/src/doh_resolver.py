"""
FatihBypass - Encrypted DNS over HTTPS (DoH) Engine
MEB UDP Port 53 DNS Zehirlenmesini ve Yönlendirmesini Atlatır
"""

import ssl
import time
import json
import socket
import fnmatch
import threading
import urllib.request
from typing import List, Optional
from .config import DOH_PROVIDERS, MEB_DIRECT_DOMAINS

class DoHResolver:
    def __init__(self, providers=None, cache_ttl=300):
        self.providers = providers or DOH_PROVIDERS
        self.cache_ttl = cache_ttl
        self._cache = {} # hostname -> (timestamp, expire_time, [ips])
        self._lock = threading.Lock()
        
        # SSL context with certificate verification disabled for bootstrap
        # Needed inside MEB firewall where custom CA or MITM may exist
        self._ssl_ctx = ssl.create_default_context()
        self._ssl_ctx.check_hostname = False
        self._ssl_ctx.verify_mode = ssl.CERT_NONE

    def is_meb_domain(self, hostname: str) -> bool:
        """Checks if a domain belongs to MEB/EBA or internal network."""
        hostname_lower = hostname.lower()
        for pattern in MEB_DIRECT_DOMAINS:
            if fnmatch.fnmatch(hostname_lower, pattern.lower()):
                return True
        return False

    def is_ip_address(self, hostname: str) -> bool:
        """Checks if the given host is an IP address string."""
        try:
            socket.inet_aton(hostname)
            return True
        except socket.error:
            pass
        try:
            socket.inet_pton(socket.AF_INET6, hostname)
            return True
        except (socket.error, AttributeError):
            pass
        return False

    def resolve(self, hostname: str, timeout: float = 3.0) -> List[str]:
        """Resolves hostname to a list of IPv4 addresses using DoH or MEB direct."""
        if not hostname:
            return []

        hostname = hostname.strip().lower()

        # If already an IP address, return immediately
        if self.is_ip_address(hostname):
            return [hostname]

        # Check local cache
        now = time.time()
        with self._lock:
            if hostname in self._cache:
                ts, exp, ips = self._cache[hostname]
                if now < exp and ips:
                    return ips

        # For MEB internal services, use system resolution directly
        if self.is_meb_domain(hostname):
            try:
                _, _, ips = socket.gethostbyname_ex(hostname)
                if ips:
                    self._cache_store(hostname, ips, ttl=600)
                    return ips
            except Exception:
                pass

        # Query DoH providers in order
        for provider in self.providers:
            try:
                ips = self._query_provider(provider, hostname, timeout=timeout)
                if ips:
                    self._cache_store(hostname, ips, ttl=self.cache_ttl)
                    return ips
            except Exception:
                continue

        # Last resort fallback: OS standard socket resolver
        try:
            _, _, ips = socket.gethostbyname_ex(hostname)
            if ips:
                self._cache_store(hostname, ips, ttl=60)
                return ips
        except Exception:
            pass

        return []

    def _query_provider(self, provider: dict, hostname: str, timeout: float) -> List[str]:
        base_url = provider["url"]
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) FatihBypass/1.0",
            "Accept": provider.get("format", "application/dns-json")
        }

        if "dns-query" in base_url:
            query_url = f"{base_url}?name={hostname}&type=A"
        else:
            query_url = f"{base_url}?name={hostname}&type=A"

        req = urllib.request.Request(query_url, headers=headers)
        with urllib.request.urlopen(req, context=self._ssl_ctx, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
            answers = data.get("Answer", [])
            ips = []
            for ans in answers:
                # Type 1 is DNS A record (IPv4)
                if ans.get("type") == 1 and "data" in ans:
                    ip = ans["data"].strip()
                    if self.is_ip_address(ip):
                        ips.append(ip)
            return ips

    def _cache_store(self, hostname: str, ips: List[str], ttl: int):
        with self._lock:
            now = time.time()
            self._cache[hostname] = (now, now + ttl, ips)

    def clear_cache(self):
        with self._lock:
            self._cache.clear()

# Global default resolver
global_doh = DoHResolver()
