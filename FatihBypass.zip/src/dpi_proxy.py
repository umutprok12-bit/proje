"""
FatihBypass - High-Performance DPI Proxy Server
Windows HTTP/HTTPS CONNECT Proxy & SOCKS5 Bridge with TLS Desync
"""

import time
import socket
import select
import struct
import threading
from typing import Optional, Callable
from .config import DEFAULT_HTTP_PORT, DEFAULT_SOCKS_PORT, DEFAULT_BIND_HOST, CIADPI_EXE
from .doh_resolver import global_doh

class DpiProxyServer:
    def __init__(
        self,
        bind_host: str = DEFAULT_BIND_HOST,
        http_port: int = DEFAULT_HTTP_PORT,
        socks_upstream_port: Optional[int] = DEFAULT_SOCKS_PORT,
        use_byedpi: bool = True,
        on_log: Optional[Callable[[str], None]] = None
    ):
        self.bind_host = bind_host
        self.http_port = http_port
        self.socks_upstream_port = socks_upstream_port
        self.use_byedpi = use_byedpi
        self.on_log = on_log

        self.running = False
        self.server_sock: Optional[socket.socket] = None
        self.server_thread: Optional[threading.Thread] = None

        # Statistics
        self.bytes_sent = 0
        self.bytes_received = 0
        self.total_connections = 0
        self.active_connections = 0
        self._stats_lock = threading.Lock()

    def log(self, message: str):
        if self.on_log:
            try:
                self.on_log(message)
            except Exception:
                pass

    def start(self):
        """Starts the HTTP proxy server in a background thread."""
        if self.running:
            return

        self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_sock.bind((self.bind_host, self.http_port))
        self.server_sock.listen(128)
        self.server_sock.settimeout(1.0)

        self.running = True
        self.server_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.server_thread.start()
        mode_str = "ByeDPI Bridge" if self.use_byedpi else "Pure-Python TLS Desync"
        self.log(f"[Proxy] Proxy {self.bind_host}:{self.http_port} üzerinde başlatıldı ({mode_str})")

    def stop(self):
        """Stops the proxy server and closes all resources."""
        self.running = False
        if self.server_sock:
            try:
                self.server_sock.close()
            except Exception:
                pass
            self.server_sock = None
        self.log("[Proxy] Proxy sunucusu durduruldu.")

    def _accept_loop(self):
        while self.running:
            try:
                client_sock, client_addr = self.server_sock.accept()
                with self._stats_lock:
                    self.total_connections += 1
                    self.active_connections += 1
                t = threading.Thread(target=self._handle_client, args=(client_sock,), daemon=True)
                t.start()
            except socket.timeout:
                continue
            except Exception:
                if not self.running:
                    break

    def _handle_client(self, client_sock: socket.socket):
        remote_sock = None
        try:
            client_sock.settimeout(10.0)
            initial_data = client_sock.recv(4096)
            if not initial_data:
                return

            # Check if this is an HTTP CONNECT request (HTTPS tunnel)
            first_line = initial_data.split(b"\r\n", 1)[0].decode("iso-8859-1", errors="ignore")
            parts = first_line.split()

            if len(parts) >= 2 and parts[0].upper() == "CONNECT":
                # HTTPS CONNECT target: host:port
                target = parts[1]
                if ":" in target:
                    target_host, target_port = target.split(":", 1)
                    target_port = int(target_port)
                else:
                    target_host, target_port = target, 443

                remote_sock = self._create_remote_connection(target_host, target_port)
                if not remote_sock:
                    client_sock.sendall(b"HTTP/1.1 502 Bad Gateway\r\n\r\n")
                    return

                # Send 200 Connection Established to client
                client_sock.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")

                # Receive first packet from client (typically TLS ClientHello)
                client_sock.settimeout(10.0)
                first_payload = client_sock.recv(4096)
                if first_payload:
                    if self.use_byedpi:
                        # ciadpi handles the desync at its level, forward directly
                        remote_sock.sendall(first_payload)
                    else:
                        # Pure Python TLS record splitting
                        self._send_desynced_tls(remote_sock, first_payload)

                # Pipe remaining data bidirectional
                self._pipe_sockets(client_sock, remote_sock)

            elif len(parts) >= 3:
                # Standard HTTP GET/POST/etc. request
                # Extract Host header
                target_host = None
                target_port = 80
                for line in initial_data.split(b"\r\n"):
                    if line.lower().startswith(b"host:"):
                        host_val = line.split(b":", 1)[1].strip().decode("iso-8859-1", errors="ignore")
                        if ":" in host_val:
                            target_host, p = host_val.split(":", 1)
                            target_port = int(p)
                        else:
                            target_host = host_val
                        break

                if not target_host:
                    return

                remote_sock = self._create_remote_connection(target_host, target_port)
                if not remote_sock:
                    client_sock.sendall(b"HTTP/1.1 502 Bad Gateway\r\n\r\n")
                    return

                # Forward HTTP request with space before colon desync if in pure python mode
                if not self.use_byedpi:
                    desynced_http = self._desync_http_request(initial_data)
                    remote_sock.sendall(desynced_http)
                else:
                    remote_sock.sendall(initial_data)

                self._pipe_sockets(client_sock, remote_sock)

        except Exception:
            pass
        finally:
            with self._stats_lock:
                self.active_connections = max(0, self.active_connections - 1)
            try:
                client_sock.close()
            except Exception:
                pass
            if remote_sock:
                try:
                    remote_sock.close()
                except Exception:
                    pass

    def _create_remote_connection(self, host: str, port: int) -> Optional[socket.socket]:
        """Creates connection to the target either via SOCKS5 (ByeDPI) or direct DoH."""
        if self.use_byedpi and self.socks_upstream_port:
            try:
                # Connect via local SOCKS5 proxy (ciadpi.exe)
                s = socket.create_connection((self.bind_host, self.socks_upstream_port), timeout=5.0)
                s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                
                # SOCKS5 Handshake
                s.sendall(b"\x05\x01\x00")
                resp = s.recv(2)
                if resp != b"\x05\x00":
                    s.close()
                    return None

                # Connect request (Domain format or IPv4)
                if global_doh.is_ip_address(host):
                    req = b"\x05\x01\x00\x01" + socket.inet_aton(host) + struct.pack("!H", port)
                else:
                    host_bytes = host.encode("ascii", errors="ignore")
                    req = b"\x05\x01\x00\x03" + bytes([len(host_bytes)]) + host_bytes + struct.pack("!H", port)

                s.sendall(req)
                resp = s.recv(10)
                if len(resp) >= 2 and resp[1] == 0x00:
                    return s
                s.close()
            except Exception:
                pass

        # Fallback to direct connection using DoH resolution
        try:
            ips = global_doh.resolve(host)
            target_ip = ips[0] if ips else host
            s = socket.create_connection((target_ip, port), timeout=5.0)
            s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            return s
        except Exception:
            return None

    def _send_desynced_tls(self, remote_sock: socket.socket, data: bytes):
        """Performs RFC-compliant TLS Record Splitting to bypass MEB FortiGate DPI."""
        # Check TLS Handshake header (0x16 0x03)
        if len(data) > 5 and data[0] == 0x16:
            try:
                record_type = data[0:1] # 0x16
                record_ver = data[1:3]  # TLS version
                record_len = struct.unpack("!H", data[3:5])[0]
                handshake_body = data[5:5 + record_len]

                if len(handshake_body) > 32:
                    # Split after 24 bytes (before the SNI extension)
                    split_at = 24
                    c1 = handshake_body[:split_at]
                    c2 = handshake_body[split_at:]

                    rec1 = record_type + record_ver + struct.pack("!H", len(c1)) + c1
                    rec2 = record_type + record_ver + struct.pack("!H", len(c2)) + c2

                    remote_sock.sendall(rec1)
                    time.sleep(0.008) # 8ms micro-delay to force separate TCP segment
                    remote_sock.sendall(rec2)
                    return
            except Exception:
                pass

        remote_sock.sendall(data)

    def _desync_http_request(self, data: bytes) -> bytes:
        """Modifies HTTP request to desync DPI inspection on port 80."""
        # Replace 'Host: ' with 'Host : ' or 'host: '
        if b"Host: " in data:
            return data.replace(b"Host: ", b"Host : ", 1)
        return data

    def _pipe_sockets(self, s1: socket.socket, s2: socket.socket):
        """High-throughput bidirectional data pipe."""
        s1.setblocking(False)
        s2.setblocking(False)
        sockets = [s1, s2]
        buffer_size = 32768

        while self.running:
            try:
                readable, _, exceptional = select.select(sockets, [], sockets, 30.0)
                if exceptional or not readable:
                    break

                for s in readable:
                    other = s2 if s is s1 else s1
                    data = s.recv(buffer_size)
                    if not data:
                        return
                    other.sendall(data)
                    with self._stats_lock:
                        if s is s1:
                            self.bytes_sent += len(data)
                        else:
                            self.bytes_received += len(data)

            except (socket.error, OSError):
                break

    def get_stats(self) -> dict:
        with self._stats_lock:
            return {
                "bytes_sent": self.bytes_sent,
                "bytes_received": self.bytes_received,
                "total_connections": self.total_connections,
                "active_connections": self.active_connections
            }
