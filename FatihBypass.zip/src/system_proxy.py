"""
FatihBypass - Windows System Proxy Controller
Windows Registry & WinINet API ile Sistem Genelinde Proxy Yönetimi
"""

import atexit
import ctypes
import winreg
from typing import Optional, Tuple
from .config import DEFAULT_HTTP_PORT, DEFAULT_BIND_HOST, MEB_DIRECT_DOMAINS

INTERNET_OPTION_SETTINGS_CHANGED = 39
INTERNET_OPTION_REFRESH = 37

REG_INTERNET_SETTINGS = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"

class SystemProxyManager:
    def __init__(self, host: str = DEFAULT_BIND_HOST, port: int = DEFAULT_HTTP_PORT):
        self.host = host
        self.port = port
        self.proxy_server_str = f"{host}:{port}"
        self.proxy_override_str = ";".join(MEB_DIRECT_DOMAINS) + ";<local>"
        
        self._original_state: Optional[Tuple[int, str, str]] = None
        self._is_applied = False
        
        # Ensure cleanup on abnormal termination
        atexit.register(self.restore_original)

    def _notify_wininet(self):
        """Notifies Windows and running browsers (Edge, Chrome, Thorium) of the proxy change."""
        try:
            wininet = ctypes.windll.wininet
            wininet.InternetSetOptionW(0, INTERNET_OPTION_SETTINGS_CHANGED, 0, 0)
            wininet.InternetSetOptionW(0, INTERNET_OPTION_REFRESH, 0, 0)
        except Exception:
            pass

    def get_current_settings(self) -> Tuple[int, str, str]:
        """Reads current proxy status from Windows Registry."""
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_INTERNET_SETTINGS, 0, winreg.KEY_READ) as key:
                enabled, _ = winreg.QueryValueEx(key, "ProxyEnable")
                try:
                    server, _ = winreg.QueryValueEx(key, "ProxyServer")
                except FileNotFoundError:
                    server = ""
                try:
                    override, _ = winreg.QueryValueEx(key, "ProxyOverride")
                except FileNotFoundError:
                    override = ""
                return (enabled, server, override)
        except Exception:
            return (0, "", "")

    def is_enabled(self) -> bool:
        enabled, server, _ = self.get_current_settings()
        return bool(enabled and server == self.proxy_server_str)

    def enable(self) -> bool:
        """Enables Windows system proxy pointing to FatihBypass."""
        try:
            if self._original_state is None:
                self._original_state = self.get_current_settings()

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_INTERNET_SETTINGS, 0, winreg.KEY_WRITE) as key:
                winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 1)
                winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, self.proxy_server_str)
                winreg.SetValueEx(key, "ProxyOverride", 0, winreg.REG_SZ, self.proxy_override_str)

            self._notify_wininet()
            self._is_applied = True
            return True
        except Exception as e:
            print(f"Error enabling system proxy: {e}")
            return False

    def disable(self) -> bool:
        """Disables Windows system proxy."""
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_INTERNET_SETTINGS, 0, winreg.KEY_WRITE) as key:
                winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 0)

            self._notify_wininet()
            self._is_applied = False
            return True
        except Exception as e:
            print(f"Error disabling system proxy: {e}")
            return False

    def restore_original(self):
        """Restores original settings that were active before FatihBypass started."""
        if not self._is_applied:
            return

        try:
            if self._original_state:
                orig_enabled, orig_server, orig_override = self._original_state
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_INTERNET_SETTINGS, 0, winreg.KEY_WRITE) as key:
                    winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, orig_enabled)
                    if orig_server:
                        winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, orig_server)
                    if orig_override:
                        winreg.SetValueEx(key, "ProxyOverride", 0, winreg.REG_SZ, orig_override)
            else:
                self.disable()
            self._notify_wininet()
            self._is_applied = False
        except Exception:
            pass

# Global system proxy instance
global_system_proxy = SystemProxyManager()
