"""
FatihBypass - MEB Root Certificate Manager
MEB Güvenlik Sertifikasını (fatihca) Windows Kök Yetkililerine Kurar/Kaldırır
"""

import os
import ssl
import subprocess
import urllib.request
from typing import Tuple
from .config import MEB_CERT_CER, MEB_CERT_CRT

class CertManager:
    def __init__(self, cert_path=MEB_CERT_CER):
        self.cert_path = cert_path

    def is_cert_installed(self) -> bool:
        """Checks if fatihca root certificate is already installed in Windows certificate store."""
        try:
            # Check current user store
            res1 = subprocess.run(
                ["certutil", "-user", "-store", "Root", "fatihca"],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            if res1.returncode == 0 and "fatihca" in res1.stdout:
                return True

            # Check local machine store
            res2 = subprocess.run(
                ["certutil", "-store", "Root", "fatihca"],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            if res2.returncode == 0 and "fatihca" in res2.stdout:
                return True

            return False
        except Exception:
            return False

    def install_cert(self) -> Tuple[bool, str]:
        """Installs MEB Root Certificate into Windows Trusted Root Certification Authorities."""
        if not self.cert_path.exists():
            # Try to download if missing
            ok, msg = self.download_cert()
            if not ok:
                return False, f"Sertifika dosyası bulunamadı ve indirilemedi: {msg}"

        try:
            # Install into CurrentUser Root store (requires no admin privileges)
            res = subprocess.run(
                ["certutil", "-user", "-addstore", "-f", "Root", str(self.cert_path)],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            if res.returncode == 0:
                return True, "MEB Sertifikası (fatihca) başarıyla sisteme kuruldu!"
            else:
                # Try machine store fallback
                res_m = subprocess.run(
                    ["certutil", "-addstore", "-f", "Root", str(self.cert_path)],
                    capture_output=True,
                    text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
                )
                if res_m.returncode == 0:
                    return True, "MEB Sertifikası Yerel Makineye başarıyla kuruldu!"
                return False, f"Sertifika yüklenirken hata oluştu: {res.stderr or res.stdout}"
        except Exception as e:
            return False, f"Sertifika kurulum hatası: {str(e)}"

    def remove_cert(self) -> Tuple[bool, str]:
        """Removes MEB Root Certificate from Windows store."""
        try:
            subprocess.run(
                ["certutil", "-user", "-delstore", "Root", "fatihca"],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            subprocess.run(
                ["certutil", "-delstore", "Root", "fatihca"],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            return True, "MEB Sertifikası sistemden kaldırıldı."
        except Exception as e:
            return False, f"Sertifika kaldırılırken hata: {str(e)}"

    def download_cert(self) -> Tuple[bool, str]:
        """Downloads the official MEB root certificate directly from sertifika.meb.gov.tr."""
        try:
            url = "https://sertifika.meb.gov.tr/MEB_SERTIFIKASI.cer"
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, context=ctx, timeout=10) as resp:
                data = resp.read()
                if len(data) > 500:
                    self.cert_path.parent.mkdir(parents=True, exist_ok=True)
                    with open(self.cert_path, "wb") as f:
                        f.write(data)
                    return True, "En güncel MEB sertifikası resmi sunucudan indirildi."
                else:
                    return False, "İndirilen sertifika boyutu geçersiz."
        except Exception as e:
            return False, f"İndirme başarısız: {str(e)}"

# Global instance
global_cert_mgr = CertManager()
