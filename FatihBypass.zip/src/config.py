"""
FatihBypass - Configuration & Settings Module
MEB FATİH Ağı (Ethernet / Wi-Fi) Kısıtlama Kaldırıcı
"""

import os
import json
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
SRC_DIR = BASE_DIR / "src"
BIN_DIR = BASE_DIR / "bin"
CERTS_DIR = BASE_DIR / "certs"
CONFIG_FILE = BASE_DIR / "settings.json"

CIADPI_EXE = BIN_DIR / "ciadpi.exe"
PSIPHON_EXE = BIN_DIR / "psiphon3.exe"
MEB_CERT_CER = CERTS_DIR / "MEB_SERTIFIKASI.cer"
MEB_CERT_CRT = CERTS_DIR / "MEB_SERTIFIKASI.crt"

# Default Network Configuration
DEFAULT_HTTP_PORT = 8085
DEFAULT_SOCKS_PORT = 1085
DEFAULT_BIND_HOST = "127.0.0.1"

# Upstream Encrypted DNS (DoH) Providers
DOH_PROVIDERS = [
    {
        "name": "Cloudflare (1.1.1.1)",
        "url": "https://1.1.1.1/dns-query",
        "format": "application/dns-json",
        "ip": "1.1.1.1"
    },
    {
        "name": "Cloudflare Secondary (1.0.0.1)",
        "url": "https://1.0.0.1/dns-query",
        "format": "application/dns-json",
        "ip": "1.0.0.1"
    },
    {
        "name": "Google (8.8.8.8)",
        "url": "https://8.8.8.8/resolve",
        "format": "application/json",
        "ip": "8.8.8.8"
    },
    {
        "name": "Google Secondary (8.8.4.4)",
        "url": "https://8.8.4.4/resolve",
        "format": "application/json",
        "ip": "8.8.4.4"
    }
]

# MEB and Intranet domains that should bypass the proxy and connect directly
MEB_DIRECT_DOMAINS = [
    "localhost",
    "127.0.0.1",
    "*.local",
    "*.lan",
    "*.meb.gov.tr",
    "*.eba.gov.tr",
    "*.meb.k12.tr",
    "sertifika.meb.gov.tr",
    "mebbis.meb.gov.tr",
    "e-okul.meb.gov.tr",
    "odsgm.meb.gov.tr",
    "fatihdestek.eba.gov.tr",
    "fatihpys.eba.gov.tr"
]

# ByeDPI presets optimized for MEB FortiGate DPI
BYEDPI_PRESETS = {
    "meb_balanced": {
        "name": "MEB Standart (Önerilen)",
        "description": "SNI parçalama ve HTTP başlık desync. MEB güvenlik duvarları için en stabil mod.",
        "args": ["-s", "1", "-q", "1", "-r", "1+s", "-M", "rmspace"]
    },
    "meb_aggressive": {
        "name": "MEB Agresif (Zorlu Okullar)",
        "description": "Fake SNI (eba.gov.tr) + ters sıra paketleme. Sıkı filtre uygulayan okullar için.",
        "args": ["-s", "1", "-d", "1", "-n", "eba.gov.tr", "-t", "6", "-M", "rmspace"]
    },
    "tls_record_split": {
        "name": "TLS Record Splitting",
        "description": "TLS el sıkışmasını RFC standartlarında iki kayda böler. Yüksek uyumluluk.",
        "args": ["-r", "24", "-M", "rmspace"]
    }
}

DEFAULT_SETTINGS = {
    "mode": "byedpi",          # "byedpi", "python", "psiphon"
    "preset": "meb_balanced",
    "http_port": DEFAULT_HTTP_PORT,
    "socks_port": DEFAULT_SOCKS_PORT,
    "enable_doh": True,
    "auto_system_proxy": True,
    "auto_repair_ethernet": False,
    "language": "tr"
}

def load_settings():
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                merged = DEFAULT_SETTINGS.copy()
                merged.update(data)
                return merged
        except Exception:
            pass
    return DEFAULT_SETTINGS.copy()

def save_settings(settings):
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=4, ensure_ascii=False)
    except Exception as e:
        print(f"Failed to save settings: {e}")
