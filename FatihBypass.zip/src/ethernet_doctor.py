"""
FatihBypass - Ethernet & Network Doctor
Kablolu / Kablosuz Ağ Teşhisi, DHCP Yenileme, DNS Temizleme ve Onarım
"""

import re
import os
import time
import socket
import urllib.request
import subprocess
from typing import List, Dict, Tuple

class EthernetDoctor:
    def __init__(self):
        pass

    def get_network_adapters(self) -> List[Dict]:
        """Scans network adapters and extracts name, status, IP, and adapter type."""
        adapters = []
        try:
            # Run PowerShell Get-NetAdapter
            cmd = "Get-NetAdapter | Select-Object Name, InterfaceDescription, Status, LinkSpeed, MediaType | ConvertTo-Json"
            res = subprocess.run(
                ["powershell", "-NoProfile", "-Command", cmd],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            if res.returncode == 0 and res.stdout.strip():
                import json
                try:
                    data = json.loads(res.stdout)
                    if isinstance(data, dict):
                        data = [data]
                    for item in data:
                        name = item.get("Name", "Bilinmeyen")
                        desc = item.get("InterfaceDescription", "")
                        status = item.get("Status", "Bilinmiyor")
                        speed = item.get("LinkSpeed", "")
                        media = str(item.get("MediaType", "")).lower()

                        is_ethernet = (
                            "ethernet" in name.lower() or 
                            "lan" in name.lower() or 
                            "kablolu" in name.lower() or
                            "802.3" in media or
                            ("wi-fi" not in name.lower() and "wireless" not in desc.lower() and "bluetooth" not in desc.lower())
                        )

                        adapters.append({
                            "name": name,
                            "desc": desc,
                            "status": status,
                            "speed": speed,
                            "is_ethernet": is_ethernet
                        })
                except Exception:
                    pass
        except Exception:
            pass

        # Fallback to ipconfig if powershell fails
        if not adapters:
            adapters.append({
                "name": "Ethernet / Wi-Fi",
                "desc": "Varsayılan Ağ Bağdaştırıcısı",
                "status": "Up",
                "speed": "Bilinmiyor",
                "is_ethernet": True
            })

        return adapters

    def repair_network(self) -> Tuple[bool, List[str]]:
        """Executes full network repair sequence (flushdns, release, renew, arpcache)."""
        logs = []
        try:
            # 1. Flush DNS
            logs.append("[1/4] DNS önbelleği temizleniyor (ipconfig /flushdns)...")
            res_flush = subprocess.run(
                ["ipconfig", "/flushdns"],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            logs.append("  -> " + res_flush.stdout.strip().replace("\r\n", " "))

            # 2. Delete ARP Cache
            logs.append("[2/4] ARP tablosu temizleniyor...")
            subprocess.run(
                ["netsh", "interface", "ip", "delete", "arpcache"],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            logs.append("  -> ARP önbelleği sıfırlandı.")

            # 3. Release DHCP lease
            logs.append("[3/4] DHCP IP adresi bırakılıyor (ipconfig /release)...")
            subprocess.run(
                ["ipconfig", "/release"],
                capture_output=True,
                text=True,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            logs.append("  -> Eski IP bırakıldı.")

            # 4. Renew DHCP lease
            logs.append("[4/4] Okul anahtarından yeni IP alınıyor (ipconfig /renew)...")
            res_renew = subprocess.run(
                ["ipconfig", "/renew"],
                capture_output=True,
                text=True,
                timeout=20,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            logs.append("  -> Yeni IP adresi başarıyla alındı.")
            logs.append("[Tamamlandı] Ağ bağlantısı başarıyla yenilendi ve onarıldı!")
            return True, logs
        except Exception as e:
            logs.append(f"[Hata] Onarım sırasında istisna: {str(e)}")
            return False, logs

    def set_adapter_dns(self, adapter_name: str, dns_mode: str = "cloudflare") -> Tuple[bool, str]:
        """Sets adapter DNS to static Cloudflare/Google or restores to DHCP."""
        try:
            if dns_mode == "dhcp":
                cmd = f'netsh interface ip set dns name="{adapter_name}" dhcp'
                res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                return res.returncode == 0, "DNS ayarları otomatik (DHCP) olarak ayarlandı."
            elif dns_mode == "cloudflare":
                cmd1 = f'netsh interface ip set dns name="{adapter_name}" static 1.1.1.1'
                cmd2 = f'netsh interface ip add dns name="{adapter_name}" 1.0.0.1 index=2'
                subprocess.run(cmd1, shell=True, capture_output=True)
                subprocess.run(cmd2, shell=True, capture_output=True)
                return True, f"{adapter_name} için DNS Cloudflare (1.1.1.1) yapıldı."
            elif dns_mode == "google":
                cmd1 = f'netsh interface ip set dns name="{adapter_name}" static 8.8.8.8'
                cmd2 = f'netsh interface ip add dns name="{adapter_name}" 8.8.4.4 index=2'
                subprocess.run(cmd1, shell=True, capture_output=True)
                subprocess.run(cmd2, shell=True, capture_output=True)
                return True, f"{adapter_name} için DNS Google (8.8.8.8) yapıldı."
            return False, "Bilinmeyen DNS modu"
        except Exception as e:
            return False, str(e)

    def test_connectivity(self, proxy_url: str = None) -> Dict[str, dict]:
        """Tests connectivity to critical MEB and external endpoints."""
        targets = [
            {"name": "MEB EBA Portalı", "url": "https://www.eba.gov.tr"},
            {"name": "MEB Sertifika Sunucusu", "url": "https://sertifika.meb.gov.tr"},
            {"name": "Cloudflare DNS (1.1.1.1)", "url": "https://1.1.1.1"},
            {"name": "Google", "url": "https://www.google.com"},
            {"name": "Discord", "url": "https://discord.com"},
            {"name": "Steam", "url": "https://store.steampowered.com"}
        ]

        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        results = {}
        for t in targets:
            start_t = time.time()
            try:
                if proxy_url:
                    proxy_handler = urllib.request.ProxyHandler({'http': proxy_url, 'https': proxy_url})
                    opener = urllib.request.build_opener(proxy_handler)
                else:
                    opener = urllib.request.build_opener()

                req = urllib.request.Request(t["url"], headers={"User-Agent": "Mozilla/5.0"})
                with opener.open(req, timeout=4) as resp:
                    elapsed = int((time.time() - start_t) * 1000)
                    results[t["name"]] = {"ok": True, "status": resp.status, "latency": elapsed}
            except Exception as e:
                elapsed = int((time.time() - start_t) * 1000)
                results[t["name"]] = {"ok": False, "error": str(e)[:40], "latency": elapsed}

        return results

# Global doctor instance
global_doctor = EthernetDoctor()
