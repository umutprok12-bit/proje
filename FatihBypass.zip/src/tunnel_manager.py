"""
FatihBypass - Tunnel & Process Manager
ciadpi.exe (ByeDPI) ve psiphon3.exe Süreçlerini Yönetir
"""

import os
import subprocess
from typing import Optional, List, Tuple
from .config import CIADPI_EXE, PSIPHON_EXE, BYEDPI_PRESETS, DEFAULT_SOCKS_PORT

class TunnelManager:
    def __init__(self):
        self.ciadpi_process: Optional[subprocess.Popen] = None
        self.psiphon_process: Optional[subprocess.Popen] = None

    def is_byedpi_running(self) -> bool:
        return self.ciadpi_process is not None and self.ciadpi_process.poll() is None

    def is_psiphon_running(self) -> bool:
        return self.psiphon_process is not None and self.psiphon_process.poll() is None

    def start_byedpi(self, port: int = DEFAULT_SOCKS_PORT, preset_key: str = "meb_balanced") -> Tuple[bool, str]:
        """Starts ciadpi.exe with the specified MEB preset."""
        if self.is_byedpi_running():
            return True, "ByeDPI zaten çalışıyor."

        if not CIADPI_EXE.exists():
            return False, f"ciadpi.exe bulunamadı: {CIADPI_EXE}"

        preset = BYEDPI_PRESETS.get(preset_key, BYEDPI_PRESETS["meb_balanced"])
        cmd = [
            str(CIADPI_EXE),
            "-i", "127.0.0.1",
            "-p", str(port)
        ] + preset["args"]

        try:
            self.ciadpi_process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
            )
            return True, f"ByeDPI başlatıldı (Port: {port}, Mod: {preset['name']})"
        except Exception as e:
            return False, f"ByeDPI başlatılamadı: {str(e)}"

    def stop_byedpi(self):
        """Stops ciadpi.exe process."""
        if self.ciadpi_process:
            try:
                self.ciadpi_process.terminate()
                self.ciadpi_process.wait(timeout=2)
            except Exception:
                try:
                    self.ciadpi_process.kill()
                except Exception:
                    pass
            self.ciadpi_process = None

    def start_psiphon(self) -> Tuple[bool, str]:
        """Launches portable Psiphon3 for full-system UDP tunnel."""
        if self.is_psiphon_running():
            return True, "Psiphon zaten çalışıyor."

        if not PSIPHON_EXE.exists():
            return False, f"psiphon3.exe bulunamadı: {PSIPHON_EXE}"

        try:
            self.psiphon_process = subprocess.Popen(
                [str(PSIPHON_EXE)],
                creationflags=0
            )
            return True, "Psiphon Tüneli başlatıldı."
        except Exception as e:
            return False, f"Psiphon başlatılamadı: {str(e)}"

    def stop_psiphon(self):
        """Stops Psiphon process."""
        if self.psiphon_process:
            try:
                self.psiphon_process.terminate()
                self.psiphon_process.wait(timeout=3)
            except Exception:
                try:
                    self.psiphon_process.kill()
                except Exception:
                    pass
            self.psiphon_process = None

    def stop_all(self):
        self.stop_byedpi()
        self.stop_psiphon()

# Global tunnel manager instance
global_tunnel_mgr = TunnelManager()
