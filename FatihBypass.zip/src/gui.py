"""
FatihBypass - Modern Graphical User Interface (GUI)
MEB FATİH Ağı Kısıtlama Kaldırıcı Grafik Arayüzü (Tkinter Modern Dark Theme)
"""

import sys
import time
import queue
import threading
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from typing import Optional

from .config import (
    DEFAULT_SETTINGS, BYEDPI_PRESETS, load_settings, save_settings,
    DEFAULT_HTTP_PORT, DEFAULT_SOCKS_PORT
)
from .dpi_proxy import DpiProxyServer
from .system_proxy import global_system_proxy
from .cert_manager import global_cert_mgr
from .ethernet_doctor import global_doctor
from .tunnel_manager import global_tunnel_mgr

# Color Palette (Modern Slate / Cyberpunk Emerald Dark)
COLOR_BG_DARK = "#0f172a"        # Deep slate background
COLOR_CARD_BG = "#1e293b"        # Card surface
COLOR_BORDER = "#334155"         # Subtle border
COLOR_TEXT_PRIMARY = "#f8fafc"   # Pure white text
COLOR_TEXT_SECONDARY = "#94a3b8" # Light grey text
COLOR_ACCENT_GREEN = "#10b981"   # Emerald active
COLOR_ACCENT_GREEN_HOVER = "#059669"
COLOR_ACCENT_RED = "#ef4444"     # Rose red inactive/stop
COLOR_ACCENT_RED_HOVER = "#dc2626"
COLOR_ACCENT_BLUE = "#3b82f6"    # Electric blue info
COLOR_CONSOLE_BG = "#090d16"     # Deep black console

class FatihBypassGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("FATİH BYPASS v1.0 — MEB Ağ Kısıtlama Kaldırıcı")
        self.root.geometry("820x680")
        self.root.minsize(780, 620)
        self.root.configure(bg=COLOR_BG_DARK)

        # Settings
        self.settings = load_settings()

        # Engine Components
        self.proxy_server: Optional[DpiProxyServer] = None
        self.is_running = False

        # Threading queue for safe GUI logging
        self.log_queue = queue.Queue()

        # Setup Styles & UI Layout
        self._setup_styles()
        self._build_header()
        self._build_main_controls()
        self._build_tabs()
        self._build_console()

        # Initial background checks
        self._poll_log_queue()
        self._update_stats_loop()
        self._check_initial_status()

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        # Configure notebook tabs
        style.configure(
            "TNotebook",
            background=COLOR_BG_DARK,
            borderwidth=0
        )
        style.configure(
            "TNotebook.Tab",
            background=COLOR_CARD_BG,
            foreground=COLOR_TEXT_SECONDARY,
            padding=[16, 8],
            font=("Segoe UI", 10, "bold"),
            borderwidth=0
        )
        style.map(
            "TNotebook.Tab",
            background=[("selected", COLOR_BORDER), ("active", COLOR_CARD_BG)],
            foreground=[("selected", COLOR_TEXT_PRIMARY), ("active", COLOR_TEXT_PRIMARY)]
        )

        # Scrollbar
        style.configure("Vertical.TScrollbar", background=COLOR_CARD_BG, troughcolor=COLOR_BG_DARK)

    def _build_header(self):
        header_frame = tk.Frame(self.root, bg=COLOR_CARD_BG, padx=20, pady=14, relief="flat", bd=1)
        header_frame.pack(fill="x", padx=14, pady=(12, 6))

        # Title & Logo
        title_box = tk.Frame(header_frame, bg=COLOR_CARD_BG)
        title_box.pack(side="left")

        title_lbl = tk.Label(
            title_box,
            text="🛡️ FATİH BYPASS",
            font=("Segoe UI", 18, "bold"),
            fg=COLOR_TEXT_PRIMARY,
            bg=COLOR_CARD_BG
        )
        title_lbl.pack(anchor="w")

        subtitle_lbl = tk.Label(
            title_box,
            text="MEB Kablolu Ethernet & Okul Wi-Fi Ağ Engeli Kaldırıcı",
            font=("Segoe UI", 9),
            fg=COLOR_TEXT_SECONDARY,
            bg=COLOR_CARD_BG
        )
        subtitle_lbl.pack(anchor="w")

        # Status Pill Badge
        self.status_pill = tk.Label(
            header_frame,
            text="● DEVRE DIŞI",
            font=("Segoe UI", 10, "bold"),
            fg="#f87171",
            bg="#451a1a",
            padx=16,
            pady=6,
            relief="flat"
        )
        self.status_pill.pack(side="right")

    def _build_main_controls(self):
        card = tk.Frame(self.root, bg=COLOR_CARD_BG, padx=20, pady=16)
        card.pack(fill="x", padx=14, pady=6)

        # Big Toggle Button
        self.btn_toggle = tk.Button(
            card,
            text="▶  BYPASS'I BAŞLAT",
            font=("Segoe UI", 14, "bold"),
            fg=COLOR_TEXT_PRIMARY,
            bg=COLOR_ACCENT_GREEN,
            activebackground=COLOR_ACCENT_GREEN_HOVER,
            activeforeground=COLOR_TEXT_PRIMARY,
            bd=0,
            cursor="hand2",
            padx=24,
            pady=12,
            command=self.toggle_bypass
        )
        self.btn_toggle.pack(fill="x", pady=(0, 12))

        # Mini status badges row
        badges_frame = tk.Frame(card, bg=COLOR_CARD_BG)
        badges_frame.pack(fill="x")

        self.lbl_cert_badge = tk.Label(
            badges_frame,
            text="📜 MEB Sertifikası: Kontrol ediliyor...",
            font=("Segoe UI", 9, "bold"),
            fg=COLOR_TEXT_SECONDARY,
            bg="#273549",
            padx=10,
            pady=5
        )
        self.lbl_cert_badge.pack(side="left", padx=(0, 8))

        self.lbl_dns_badge = tk.Label(
            badges_frame,
            text="🔒 DoH DNS: Cloudflare/Google Aktif",
            font=("Segoe UI", 9, "bold"),
            fg="#34d399",
            bg="#064e3b",
            padx=10,
            pady=5
        )
        self.lbl_dns_badge.pack(side="left", padx=8)

        self.lbl_proxy_badge = tk.Label(
            badges_frame,
            text=f"🌐 Proxy: 127.0.0.1:{self.settings['http_port']}",
            font=("Segoe UI", 9, "bold"),
            fg=COLOR_TEXT_SECONDARY,
            bg="#273549",
            padx=10,
            pady=5
        )
        self.lbl_proxy_badge.pack(side="right")

    def _build_tabs(self):
        tab_container = tk.Frame(self.root, bg=COLOR_BG_DARK)
        tab_container.pack(fill="both", expand=True, padx=14, pady=6)

        self.notebook = ttk.Notebook(tab_container)
        self.notebook.pack(fill="both", expand=True)

        # Tab 1: Dashboard / Stats
        self.tab_dashboard = tk.Frame(self.notebook, bg=COLOR_CARD_BG, padx=14, pady=12)
        self.notebook.add(self.tab_dashboard, text="📊 Durum & Hız")
        self._build_dashboard_tab()

        # Tab 2: Ethernet Doctor
        self.tab_doctor = tk.Frame(self.notebook, bg=COLOR_CARD_BG, padx=14, pady=12)
        self.notebook.add(self.tab_doctor, text="🛠️ Kablolu Ağ Doktoru")
        self._build_doctor_tab()

        # Tab 3: Cert Manager
        self.tab_cert = tk.Frame(self.notebook, bg=COLOR_CARD_BG, padx=14, pady=12)
        self.notebook.add(self.tab_cert, text="📜 MEB Sertifikası")
        self._build_cert_tab()

        # Tab 4: Settings / Advanced
        self.tab_settings = tk.Frame(self.notebook, bg=COLOR_CARD_BG, padx=14, pady=12)
        self.notebook.add(self.tab_settings, text="⚙️ Mod & Ayarlar")
        self._build_settings_tab()

    def _build_dashboard_tab(self):
        # Stats Cards Grid
        grid = tk.Frame(self.tab_dashboard, bg=COLOR_CARD_BG)
        grid.pack(fill="x", pady=(0, 10))

        # Sent
        c1 = tk.Frame(grid, bg="#0f172a", padx=14, pady=10, bd=1, relief="ridge")
        c1.pack(side="left", fill="both", expand=True, padx=4)
        tk.Label(c1, text="GÖNDERİLEN VERİ", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_SECONDARY, bg="#0f172a").pack(anchor="w")
        self.lbl_stat_sent = tk.Label(c1, text="0.00 MB", font=("Segoe UI", 16, "bold"), fg="#60a5fa", bg="#0f172a")
        self.lbl_stat_sent.pack(anchor="w")

        # Received
        c2 = tk.Frame(grid, bg="#0f172a", padx=14, pady=10, bd=1, relief="ridge")
        c2.pack(side="left", fill="both", expand=True, padx=4)
        tk.Label(c2, text="ALINAN VERİ", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_SECONDARY, bg="#0f172a").pack(anchor="w")
        self.lbl_stat_recv = tk.Label(c2, text="0.00 MB", font=("Segoe UI", 16, "bold"), fg="#34d399", bg="#0f172a")
        self.lbl_stat_recv.pack(anchor="w")

        # Connections
        c3 = tk.Frame(grid, bg="#0f172a", padx=14, pady=10, bd=1, relief="ridge")
        c3.pack(side="left", fill="both", expand=True, padx=4)
        tk.Label(c3, text="AKTİF / TOPLAM BAĞLANTI", font=("Segoe UI", 8, "bold"), fg=COLOR_TEXT_SECONDARY, bg="#0f172a").pack(anchor="w")
        self.lbl_stat_conns = tk.Label(c3, text="0 / 0", font=("Segoe UI", 16, "bold"), fg="#fbbf24", bg="#0f172a")
        self.lbl_stat_conns.pack(anchor="w")

        # Connectivity Test Bar
        test_bar = tk.Frame(self.tab_dashboard, bg=COLOR_CARD_BG)
        test_bar.pack(fill="x", pady=6)

        btn_test = tk.Button(
            test_bar,
            text="⚡ Hızlı Bağlantı & Engel Testi Yap",
            font=("Segoe UI", 10, "bold"),
            bg="#2563eb",
            fg="white",
            bd=0,
            cursor="hand2",
            padx=14,
            pady=6,
            command=self.run_connectivity_test
        )
        btn_test.pack(side="left")

        self.lbl_test_status = tk.Label(
            test_bar,
            text="",
            font=("Segoe UI", 9),
            fg=COLOR_TEXT_SECONDARY,
            bg=COLOR_CARD_BG,
            padx=10
        )
        self.lbl_test_status.pack(side="left")

        # Test Results List
        self.test_results_box = tk.Text(
            self.tab_dashboard,
            height=5,
            bg=COLOR_CONSOLE_BG,
            fg=COLOR_TEXT_PRIMARY,
            font=("Consolas", 9),
            bd=0,
            padx=10,
            pady=8
        )
        self.test_results_box.pack(fill="both", expand=True, pady=(4, 0))
        self.test_results_box.insert("1.0", "Hazır. Test yapmak için butona tıklayın.\n")
        self.test_results_box.config(state="disabled")

    def _build_doctor_tab(self):
        desc = tk.Label(
            self.tab_doctor,
            text="Okul Ethernet kablosunu bilgisayarınıza taktığınızda 'Tanımlanamayan Ağ', DNS hatası veya IP çakışması oluyorsa bu araç tek tıkla ağınızı onarır ve sıfırlar.",
            font=("Segoe UI", 9),
            fg=COLOR_TEXT_SECONDARY,
            bg=COLOR_CARD_BG,
            wraplength=740,
            justify="left"
        )
        desc.pack(anchor="w", pady=(0, 10))

        # Action Buttons
        btn_box = tk.Frame(self.tab_doctor, bg=COLOR_CARD_BG)
        btn_box.pack(fill="x", pady=6)

        btn_repair = tk.Button(
            btn_box,
            text="🛠️ Kablolu Ağı Onar & IP Yenile (FlushDNS / Release / Renew)",
            font=("Segoe UI", 10, "bold"),
            bg="#0284c7",
            fg="white",
            bd=0,
            cursor="hand2",
            padx=14,
            pady=8,
            command=self.run_network_repair
        )
        btn_repair.pack(side="left", padx=(0, 8))

        # DNS Quick Switchers
        dns_box = tk.LabelFrame(
            self.tab_doctor,
            text="Ağ Bağdaştırıcısı DNS Değiştirici",
            bg=COLOR_CARD_BG,
            fg=COLOR_TEXT_PRIMARY,
            font=("Segoe UI", 9, "bold"),
            padx=10,
            pady=10
        )
        dns_box.pack(fill="x", pady=10)

        tk.Button(
            dns_box,
            text="Cloudflare DNS (1.1.1.1)",
            font=("Segoe UI", 9),
            bg="#334155",
            fg="white",
            bd=0,
            cursor="hand2",
            padx=10,
            pady=5,
            command=lambda: self.set_dns("cloudflare")
        ).pack(side="left", padx=4)

        tk.Button(
            dns_box,
            text="Google DNS (8.8.8.8)",
            font=("Segoe UI", 9),
            bg="#334155",
            fg="white",
            bd=0,
            cursor="hand2",
            padx=10,
            pady=5,
            command=lambda: self.set_dns("google")
        ).pack(side="left", padx=4)

        tk.Button(
            dns_box,
            text="Otomatik DNS (DHCP)",
            font=("Segoe UI", 9),
            bg="#475569",
            fg="white",
            bd=0,
            cursor="hand2",
            padx=10,
            pady=5,
            command=lambda: self.set_dns("dhcp")
        ).pack(side="left", padx=4)

        # Adapters List
        tk.Label(
            self.tab_doctor,
            text="Mevcut Ağ Bağdaştırıcıları:",
            font=("Segoe UI", 9, "bold"),
            fg=COLOR_TEXT_PRIMARY,
            bg=COLOR_CARD_BG
        ).pack(anchor="w", pady=(8, 4))

        self.adapters_box = tk.Text(
            self.tab_doctor,
            height=5,
            bg=COLOR_CONSOLE_BG,
            fg=COLOR_TEXT_PRIMARY,
            font=("Consolas", 9),
            bd=0,
            padx=8,
            pady=6
        )
        self.adapters_box.pack(fill="both", expand=True)
        self._refresh_adapters()

    def _build_cert_tab(self):
        desc = tk.Label(
            self.tab_cert,
            text="MEB Fatih ağında HTTPS sitelerine erişirken 'Bağlantınız gizli değil' (ERR_CERT_AUTHORITY_INVALID) hatası alıyorsanız MEB Kök Sertifikasının (fatihca) kurulu olması gerekir. Bu araç sertifikayı tek tıkla kurar.",
            font=("Segoe UI", 9),
            fg=COLOR_TEXT_SECONDARY,
            bg=COLOR_CARD_BG,
            wraplength=740,
            justify="left"
        )
        desc.pack(anchor="w", pady=(0, 10))

        self.lbl_cert_detailed = tk.Label(
            self.tab_cert,
            text="Durum kontrol ediliyor...",
            font=("Segoe UI", 11, "bold"),
            fg=COLOR_TEXT_PRIMARY,
            bg=COLOR_CARD_BG
        )
        self.lbl_cert_detailed.pack(anchor="w", pady=6)

        actions = tk.Frame(self.tab_cert, bg=COLOR_CARD_BG)
        actions.pack(fill="x", pady=10)

        btn_install = tk.Button(
            actions,
            text="📥 MEB Sertifikasını Sisteme Yükle",
            font=("Segoe UI", 10, "bold"),
            bg="#059669",
            fg="white",
            bd=0,
            cursor="hand2",
            padx=14,
            pady=8,
            command=self.install_cert
        )
        btn_install.pack(side="left", padx=(0, 8))

        btn_uninstall = tk.Button(
            actions,
            text="🗑️ MEB Sertifikasını Sistemden Kaldır",
            font=("Segoe UI", 10),
            bg="#dc2626",
            fg="white",
            bd=0,
            cursor="hand2",
            padx=14,
            pady=8,
            command=self.remove_cert
        )
        btn_uninstall.pack(side="left", padx=8)

        btn_download = tk.Button(
            actions,
            text="🔄 Resmi Sunucudan Güncelle",
            font=("Segoe UI", 10),
            bg="#334155",
            fg="white",
            bd=0,
            cursor="hand2",
            padx=14,
            pady=8,
            command=self.download_cert
        )
        btn_download.pack(side="left", padx=8)

        help_box = tk.LabelFrame(
            self.tab_cert,
            text="Sertifika Bilgisi",
            bg=COLOR_CARD_BG,
            fg=COLOR_TEXT_PRIMARY,
            font=("Segoe UI", 9, "bold"),
            padx=10,
            pady=8
        )
        help_box.pack(fill="both", expand=True, pady=8)

        help_text = (
            "• Sertifika Adı: fatihca (Milli Eğitim Bakanlığı Kök Sertifikası)\n"
            "• Konum: Windows Güvenilen Kök Sertifika Yetkilileri (Root)\n"
            "• Geçerlilik: 2016 - 2036\n"
            "• Güvenlik: Sertifika kurulduğunda MEB güvenlik duvarı denetimindeki okul siteleri (EBA, MEBBİS vb.) tarayıcınızda kırmızı uyarı vermeden sorunsuz açılır."
        )
        tk.Label(
            help_box,
            text=help_text,
            font=("Segoe UI", 9),
            fg=COLOR_TEXT_SECONDARY,
            bg=COLOR_CARD_BG,
            justify="left"
        ).pack(anchor="w")

    def _build_settings_tab(self):
        # Mode Selection
        mode_box = tk.LabelFrame(
            self.tab_settings,
            text="Bypass Motoru Seçimi",
            bg=COLOR_CARD_BG,
            fg=COLOR_TEXT_PRIMARY,
            font=("Segoe UI", 9, "bold"),
            padx=12,
            pady=8
        )
        mode_box.pack(fill="x", pady=6)

        self.var_mode = tk.StringVar(value=self.settings.get("mode", "byedpi"))

        rb1 = tk.Radiobutton(
            mode_box,
            text="ByeDPI + Encrypted DoH DNS (Önerilen: En Yüksek Hız, Donanım Hızlandırmalı)",
            variable=self.var_mode,
            value="byedpi",
            bg=COLOR_CARD_BG,
            fg=COLOR_TEXT_PRIMARY,
            selectcolor="#0f172a",
            font=("Segoe UI", 9)
        )
        rb1.pack(anchor="w", pady=2)

        rb2 = tk.Radiobutton(
            mode_box,
            text="Pure Python TLS Record Splitting (Sıfır Dış Bağımlılık, Gömülü Motor)",
            variable=self.var_mode,
            value="python",
            bg=COLOR_CARD_BG,
            fg=COLOR_TEXT_PRIMARY,
            selectcolor="#0f172a",
            font=("Segoe UI", 9)
        )
        rb2.pack(anchor="w", pady=2)

        rb3 = tk.Radiobutton(
            mode_box,
            text="Psiphon 3 Portable Tünel (Oyunlar ve Tam UDP Tünelleme Gerektiren Durumlar)",
            variable=self.var_mode,
            value="psiphon",
            bg=COLOR_CARD_BG,
            fg=COLOR_TEXT_PRIMARY,
            selectcolor="#0f172a",
            font=("Segoe UI", 9)
        )
        rb3.pack(anchor="w", pady=2)

        # Presets Selection
        preset_box = tk.LabelFrame(
            self.tab_settings,
            text="MEB Güvenlik Duvarı Önayarı (ByeDPI Modu)",
            bg=COLOR_CARD_BG,
            fg=COLOR_TEXT_PRIMARY,
            font=("Segoe UI", 9, "bold"),
            padx=12,
            pady=8
        )
        preset_box.pack(fill="x", pady=6)

        self.var_preset = tk.StringVar(value=self.settings.get("preset", "meb_balanced"))
        for k, v in BYEDPI_PRESETS.items():
            tk.Radiobutton(
                preset_box,
                text=f"{v['name']} — {v['description']}",
                variable=self.var_preset,
                value=k,
                bg=COLOR_CARD_BG,
                fg=COLOR_TEXT_PRIMARY,
                selectcolor="#0f172a",
                font=("Segoe UI", 9)
            ).pack(anchor="w", pady=2)

        # Save Button
        btn_save = tk.Button(
            self.tab_settings,
            text="💾 Ayarları Kaydet",
            font=("Segoe UI", 10, "bold"),
            bg="#2563eb",
            fg="white",
            bd=0,
            cursor="hand2",
            padx=14,
            pady=6,
            command=self.save_user_settings
        )
        btn_save.pack(anchor="w", pady=10)

    def _build_console(self):
        console_frame = tk.Frame(self.root, bg=COLOR_BG_DARK, padx=14, pady=4)
        console_frame.pack(fill="both", expand=True)

        header = tk.Frame(console_frame, bg=COLOR_BG_DARK)
        header.pack(fill="x", pady=(0, 4))

        tk.Label(
            header,
            text="CANLI ETKİNLİK GÜNLÜĞÜ (LOG)",
            font=("Segoe UI", 8, "bold"),
            fg=COLOR_TEXT_SECONDARY,
            bg=COLOR_BG_DARK
        ).pack(side="left")

        btn_clear = tk.Button(
            header,
            text="Temizle",
            font=("Segoe UI", 8),
            fg=COLOR_TEXT_SECONDARY,
            bg=COLOR_CARD_BG,
            bd=0,
            cursor="hand2",
            command=self.clear_console
        )
        btn_clear.pack(side="right")

        self.console = scrolledtext.ScrolledText(
            console_frame,
            height=6,
            bg=COLOR_CONSOLE_BG,
            fg="#e2e8f0",
            insertbackground="white",
            font=("Consolas", 9),
            bd=0,
            padx=8,
            pady=6
        )
        self.console.pack(fill="both", expand=True)

    def log(self, message: str):
        """Thread-safe logging to GUI console."""
        t_str = time.strftime("%H:%M:%S")
        self.log_queue.put(f"[{t_str}] {message}")

    def _poll_log_queue(self):
        while not self.log_queue.empty():
            msg = self.log_queue.get()
            self.console.insert("end", msg + "\n")
            self.console.see("end")
        self.root.after(100, self._poll_log_queue)

    def clear_console(self):
        self.console.delete("1.0", "end")

    def _check_initial_status(self):
        """Checks certificate and system proxy status on startup."""
        self.log("FatihBypass v1.0 başlatıldı. Ağ parametreleri taranıyor...")
        installed = global_cert_mgr.is_cert_installed()
        if installed:
            self.lbl_cert_badge.config(text="📜 MEB Sertifikası: Kurulu (fatihca)", fg="#34d399", bg="#064e3b")
            self.lbl_cert_detailed.config(text="✓ MEB Sertifikası (fatihca) sisteminizde kurulu ve aktif.", fg="#34d399")
            self.log("[Sertifika] MEB fatihca kök sertifikası bulundu.")
        else:
            self.lbl_cert_badge.config(text="⚠️ MEB Sertifikası: Eksik", fg="#fbbf24", bg="#451a03")
            self.lbl_cert_detailed.config(text="⚠️ MEB Sertifikası henüz kurulu değil. (Aşağıdaki butondan yükleyin)", fg="#fbbf24")
            self.log("[Uyarı] MEB Sertifikası kurulu değil. 'Sertifikayı Yükle' sekmesinden tek tıkla kurabilirsiniz.")

    def _refresh_adapters(self):
        def worker():
            adapters = global_doctor.get_network_adapters()
            text = ""
            for a in adapters:
                icon = "🔌 [KABLOLU]" if a["is_ethernet"] else "📶 [WIFI]"
                text += f"{icon} {a['name']}: {a['desc']} | Durum: {a['status']} | Hız: {a['speed']}\n"
            self.root.after(0, lambda: self._update_adapters_ui(text))
        threading.Thread(target=worker, daemon=True).start()

    def _update_adapters_ui(self, text: str):
        self.adapters_box.config(state="normal")
        self.adapters_box.delete("1.0", "end")
        self.adapters_box.insert("1.0", text)
        self.adapters_box.config(state="disabled")

    def toggle_bypass(self):
        if self.is_running:
            self.stop_bypass()
        else:
            self.start_bypass()

    def start_bypass(self):
        mode = self.var_mode.get()
        preset = self.var_preset.get()
        http_port = self.settings.get("http_port", DEFAULT_HTTP_PORT)
        socks_port = self.settings.get("socks_port", DEFAULT_SOCKS_PORT)

        self.log(f"[Başlatılıyor] Mod: {mode.upper()}...")

        if mode == "psiphon":
            # Psiphon Tunnel Mode
            ok, msg = global_tunnel_mgr.start_psiphon()
            self.log(msg)
            if not ok:
                messagebox.showerror("Hata", msg)
                return
            self._set_active_ui(True)
            return

        # ByeDPI Mode
        if mode == "byedpi":
            ok, msg = global_tunnel_mgr.start_byedpi(port=socks_port, preset_key=preset)
            self.log(f"[ByeDPI] {msg}")
            if not ok:
                self.log(f"[Uyarı] ByeDPI başlatılamadı, pure python moduna geçiliyor: {msg}")
                use_byedpi = False
            else:
                use_byedpi = True
        else:
            use_byedpi = False

        # Start Local Proxy Server
        try:
            self.proxy_server = DpiProxyServer(
                http_port=http_port,
                socks_upstream_port=socks_port if use_byedpi else None,
                use_byedpi=use_byedpi,
                on_log=self.log
            )
            self.proxy_server.start()
        except Exception as e:
            self.log(f"[Hata] Proxy sunucusu başlatılamadı: {e}")
            messagebox.showerror("Hata", f"Proxy başlatılamadı: {e}")
            global_tunnel_mgr.stop_all()
            return

        # Enable Windows System Proxy
        if self.settings.get("auto_system_proxy", True):
            global_system_proxy.port = http_port
            global_system_proxy.proxy_server_str = f"127.0.0.1:{http_port}"
            ok_proxy = global_system_proxy.enable()
            if ok_proxy:
                self.log(f"[Sistem] Windows Sistem Proxy aktif edildi -> 127.0.0.1:{http_port}")
            else:
                self.log("[Uyarı] Windows Sistem Proxy etkinleştirilemedi.")

        self._set_active_ui(True)
        self.log("🚀 [BAŞARILI] Fatih MEB Bypass devrede! Artık tüm engellenen sitelere erişebilirsiniz.")

    def stop_bypass(self):
        self.log("[Durduruluyor] Bypass servisleri kapatılıyor...")

        # Disable System Proxy
        global_system_proxy.disable()
        self.log("[Sistem] Windows Sistem Proxy devre dışı bırakıldı.")

        # Stop Proxy Server
        if self.proxy_server:
            self.proxy_server.stop()
            self.proxy_server = None

        # Stop Tunnels
        global_tunnel_mgr.stop_all()
        self.log("[Tünel] Tüm tünel süreçleri sonlandırıldı.")

        self._set_active_ui(False)
        self.log("⏹️ [DURDURULDU] Sistem normal ağ moduna döndü.")

    def _set_active_ui(self, active: bool):
        self.is_running = active
        if active:
            self.status_pill.config(text="● AKTİF — KORUNUYOR", fg="#34d399", bg="#064e3b")
            self.btn_toggle.config(
                text="⏹  BYPASS'I DURDUR",
                bg=COLOR_ACCENT_RED,
                activebackground=COLOR_ACCENT_RED_HOVER
            )
        else:
            self.status_pill.config(text="● DEVRE DIŞI", fg="#f87171", bg="#451a1a")
            self.btn_toggle.config(
                text="▶  BYPASS'I BAŞLAT",
                bg=COLOR_ACCENT_GREEN,
                activebackground=COLOR_ACCENT_GREEN_HOVER
            )

    def _update_stats_loop(self):
        if self.proxy_server and self.is_running:
            stats = self.proxy_server.get_stats()
            sent_mb = stats["bytes_sent"] / (1024 * 1024)
            recv_mb = stats["bytes_received"] / (1024 * 1024)
            self.lbl_stat_sent.config(text=f"{sent_mb:.2f} MB")
            self.lbl_stat_recv.config(text=f"{recv_mb:.2f} MB")
            self.lbl_stat_conns.config(text=f"{stats['active_connections']} / {stats['total_connections']}")
        self.root.after(1000, self._update_stats_loop)

    def run_connectivity_test(self):
        self.lbl_test_status.config(text="Test yapılıyor...", fg=COLOR_ACCENT_BLUE)
        self.test_results_box.config(state="normal")
        self.test_results_box.delete("1.0", "end")
        self.test_results_box.insert("1.0", "Bağlantı testleri başlatıldı...\n")
        self.test_results_box.config(state="disabled")

        def worker():
            proxy_url = f"http://127.0.0.1:{self.settings.get('http_port', DEFAULT_HTTP_PORT)}" if self.is_running else None
            res = global_doctor.test_connectivity(proxy_url=proxy_url)
            self.root.after(0, lambda: self._update_test_results(res))

        threading.Thread(target=worker, daemon=True).start()

    def _update_test_results(self, results: dict):
        self.test_results_box.config(state="normal")
        self.test_results_box.delete("1.0", "end")
        for name, data in results.items():
            if data.get("ok"):
                self.test_results_box.insert("end", f"✓ [{data['latency']}ms] {name}: AÇIK (Erişilebilir)\n")
            else:
                self.test_results_box.insert("end", f"✗ [{data['latency']}ms] {name}: ENGELLİ / HATA ({data.get('error', 'Timeout')})\n")
        self.test_results_box.config(state="disabled")
        self.lbl_test_status.config(text="Test tamamlandı.", fg="#34d399")

    def run_network_repair(self):
        self.log("[Doktor] Kablolu ağ onarımı başlatıldı (ipconfig /flushdns, release, renew)...")
        def worker():
            ok, logs = global_doctor.repair_network()
            for l in logs:
                self.log(f"[Doktor] {l}")
            self._refresh_adapters()
            if ok:
                self.root.after(0, lambda: messagebox.showinfo("Tamamlandı", "Ağ bağlantısı ve DHCP adresi başarıyla onarıldı!"))
            else:
                self.root.after(0, lambda: messagebox.showwarning("Onarım Uyarısı", "Onarım kısmen tamamlandı. Günlükleri inceleyin."))
        threading.Thread(target=worker, daemon=True).start()

    def set_dns(self, mode: str):
        adapters = global_doctor.get_network_adapters()
        target = "Ethernet"
        for a in adapters:
            if a["is_ethernet"] and a["status"].lower() == "up":
                target = a["name"]
                break
        self.log(f"[DNS] {target} için DNS ayarı yapılıyor: {mode}...")
        def worker():
            ok, msg = global_doctor.set_adapter_dns(target, mode)
            self.log(f"[DNS] {msg}")
            if ok:
                self.root.after(0, lambda: messagebox.showinfo("DNS", msg))
            else:
                self.root.after(0, lambda: messagebox.showwarning("DNS", f"DNS değiştirilemedi (Yönetici hakları gerekebilir): {msg}"))
        threading.Thread(target=worker, daemon=True).start()

    def install_cert(self):
        self.log("[Sertifika] MEB kök sertifikası yükleniyor...")
        ok, msg = global_cert_mgr.install_cert()
        self.log(f"[Sertifika] {msg}")
        if ok:
            self._check_initial_status()
            messagebox.showinfo("Sertifika", msg)
        else:
            messagebox.showerror("Sertifika Hatası", msg)

    def remove_cert(self):
        ok, msg = global_cert_mgr.remove_cert()
        self.log(f"[Sertifika] {msg}")
        self._check_initial_status()
        messagebox.showinfo("Sertifika", msg)

    def download_cert(self):
        self.log("[Sertifika] Güncel sertifika indiriliyor...")
        ok, msg = global_cert_mgr.download_cert()
        self.log(f"[Sertifika] {msg}")
        messagebox.showinfo("Sertifika İndirme", msg)

    def save_user_settings(self):
        self.settings["mode"] = self.var_mode.get()
        self.settings["preset"] = self.var_preset.get()
        save_settings(self.settings)
        self.log("[Ayarlar] Kullanıcı tercihleri kaydedildi.")
        messagebox.showinfo("Ayarlar", "Ayarlar başarıyla kaydedildi.")

def launch_gui():
    root = tk.Tk()
    app = FatihBypassGUI(root)

    def on_closing():
        if app.is_running:
            if messagebox.askyesno("Çıkış", "FatihBypass halen aktif. Kapatmadan önce bypass'ı durdurmak ister misiniz?"):
                app.stop_bypass()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()

if __name__ == "__main__":
    launch_gui()
