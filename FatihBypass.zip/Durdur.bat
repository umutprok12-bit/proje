@echo off
title FatihBypass Durdurucu
cd /d "%~dp0"

echo ========================================================
echo   FATIH BYPASS - Ag Ayarlari Sifirlaniyor
echo ========================================================

python cli.py --stop
if %ERRORLEVEL% neq 0 (
    py -3 cli.py --stop
)

echo.
echo [TAMAMLANDI] Tum proxy ayarlari sifirlandi ve tüneller kapatildi.
timeout /t 3
