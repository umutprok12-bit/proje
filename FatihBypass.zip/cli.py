"""
FatihBypass - Command Line Interface (CLI)
Komut Satırı Üzerinden Hızlı Yönetim ve Otomasyon
"""

import sys
import os
import time
import argparse

# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
from src.config import DEFAULT_HTTP_PORT, DEFAULT_SOCKS_PORT, BYEDPI_PRESETS
from src.dpi_proxy import DpiProxyServer
from src.system_proxy import global_system_proxy
from src.cert_manager import global_cert_mgr
from src.ethernet_doctor import global_doctor
from src.tunnel_manager import global_tunnel_mgr

def print_banner():
    print("=" * 60)
    print("  FATİH BYPASS v1.0 — MEB Kısıtlama Kaldırıcı (CLI)")
    print("  MEB Ethernet & Okul Wi-Fi Ağ Engeli Çözümü")
    print("=" * 60)

def cmd_status():
    print_banner()
    cert_ok = global_cert_mgr.is_cert_installed()
    proxy_ok = global_system_proxy.is_enabled()
    print(f"[*] MEB Sertifikası (fatihca): {'KURULU [✓]' if cert_ok else 'EKSİK [✗]'}")
    print(f"[*] Windows Sistem Proxy:      {'AKTİF [✓]' if proxy_ok else 'DEVRE DIŞI [✗]'}")
    print("\n[*] Ağ Bağdaştırıcıları:")
    for a in global_doctor.get_network_adapters():
        tag = "[KABLOLU]" if a["is_ethernet"] else "[WIFI]"
        print(f"    - {tag} {a['name']}: {a['desc']} ({a['status']})")
    print("=" * 60)

def cmd_install_cert():
    print("[*] MEB Sertifikası kuruluyor...")
    ok, msg = global_cert_mgr.install_cert()
    print(f"[{'BAŞARILI' if ok else 'HATA'}] {msg}")

def cmd_repair():
    print("[*] Kablolu ağ onarımı başlatılıyor...")
    ok, logs = global_doctor.repair_network()
    for l in logs:
        print(f"    {l}")
    print(f"[{'TAMAMLANDI' if ok else 'UYARI'}] Onarım işlemi bitti.")

def cmd_stop():
    print("[*] FatihBypass durduruluyor...")
    global_system_proxy.disable()
    global_tunnel_mgr.stop_all()
    print("[✓] Sistem Proxy devre dışı bırakıldı ve tüneller kapatıldı.")

def cmd_start(mode="byedpi", preset="meb_balanced", http_port=DEFAULT_HTTP_PORT, socks_port=DEFAULT_SOCKS_PORT):
    print_banner()
    print(f"[*] Mod: {mode.upper()} | Önayar: {preset} | HTTP Port: {http_port}")

    if mode == "psiphon":
        ok, msg = global_tunnel_mgr.start_psiphon()
        print(f"[{'BAŞARILI' if ok else 'HATA'}] {msg}")
        return

    use_byedpi = (mode == "byedpi")
    if use_byedpi:
        ok, msg = global_tunnel_mgr.start_byedpi(port=socks_port, preset_key=preset)
        print(f"[*] {msg}")
        if not ok:
            print("[!] ByeDPI başlatılamadı, pure python motoru kullanılacak.")
            use_byedpi = False

    def log_cb(msg):
        print(f"[{time.strftime('%H:%M:%S')}] {msg}")

    server = DpiProxyServer(
        http_port=http_port,
        socks_upstream_port=socks_port if use_byedpi else None,
        use_byedpi=use_byedpi,
        on_log=log_cb
    )
    server.start()

    global_system_proxy.port = http_port
    global_system_proxy.proxy_server_str = f"127.0.0.1:{http_port}"
    global_system_proxy.enable()
    print(f"[✓] Windows Sistem Proxy aktif: 127.0.0.1:{http_port}")
    print("[✓] FatihBypass çalışıyor! Çıkmak için CTRL+C tuşlarına basın...\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[*] Kapatılıyor...")
        global_system_proxy.disable()
        server.stop()
        global_tunnel_mgr.stop_all()
        print("[✓] Temiz bir şekilde kapatıldı.")

def main():
    parser = argparse.ArgumentParser(description="FatihBypass CLI")
    parser.add_argument("--start", action="store_true", help="Bypass'ı başlat")
    parser.add_argument("--stop", action="store_true", help="Bypass'ı durdur")
    parser.add_argument("--status", action="store_true", help="Mevcut durumu göster")
    parser.add_argument("--install-cert", action="store_true", help="MEB Sertifikasını kur")
    parser.add_argument("--repair", action="store_true", help="Ağ bağlantısını onar ve DHCP yenile")
    parser.add_argument("--mode", choices=["byedpi", "python", "psiphon"], default="byedpi", help="Bypass modu")
    parser.add_argument("--preset", choices=list(BYEDPI_PRESETS.keys()), default="meb_balanced", help="ByeDPI önayarı")

    args = parser.parse_args()

    if args.status:
        cmd_status()
    elif args.install_cert:
        cmd_install_cert()
    elif args.repair:
        cmd_repair()
    elif args.stop:
        cmd_stop()
    elif args.start:
        cmd_start(mode=args.mode, preset=args.preset)
    else:
        cmd_status()
        print("\nKullanım ipucu: python cli.py --start veya grafik arayüz için python main.py")

if __name__ == "__main__":
    main()
