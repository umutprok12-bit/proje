@echo off
title MEB Sertifikasi Kurucu
cd /d "%~dp0"

echo ========================================================
echo   MEB FATIH KOK SERTIFIKASI (fatihca) YUKLENIYOR
echo ========================================================

python cli.py --install-cert
if %ERRORLEVEL% neq 0 (
    py -3 cli.py --install-cert
)

echo.
pause
