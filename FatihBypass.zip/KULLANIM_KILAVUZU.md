# 🛡️ FATİH BYPASS v1.0 — KULLANIM KILAVUZU
**MEB FATİH Ağı (Kablolu Ethernet & Wi-Fi) Kısıtlama Kaldırıcı**

---

## 📌 1. MEB FATİH Ağındaki Engeller Nelerdir ve Nasıl Aşılır?

MEB Fatih altyapısında (özellikle okul ethernet kablosu takıldığında) internet erişiminin engellenmesinin 4 ana sebebi vardır:

1. **DNS Zehirlenmesi (Port 53 Engeli):**
   - MEB, standart DNS sorgularını kendi sunucularına (`195.175.39.39`) yönlendirir veya engellenen sitelere `0.0.0.0` ya da engelleme sayfası IP'si döner.
   - **FatihBypass Çözümü:** 443 portu üzerinden **DoH (DNS-over-HTTPS)** kullanarak sorguları Cloudflare (1.1.1.1) ve Google (8.8.8.8) üzerinden uçtan uca şifreler. MEB DNS'i göremez.

2. **DPI ve SNI Denetimi (Deep Packet Inspection):**
   - Okul güvenlik duvarı (FortiGate), HTTPS bağlantısı başlarken gönderilen `ClientHello` paketindeki web sitesi adını (SNI) inceler. Eğer Discord, Steam, Instagram vb. ise bağlantıyı anında keser (TCP RST).
   - **FatihBypass Çözümü:** **TLS Record Splitting ve SNI Parçalama** motoru sayesinde ilk paketi 2 parçaya böler. Güvenlik duvarı paket içinde site ismini tespit edemez ve trafiği serbest bırakır. Uzak sunucu ise paketi birleştirip bağlantıyı sorunsuz tamamlar. Bu sayede **hiçbir hız düşüşü yaşanmaz, doğrudan hat hızında çalışır.**

3. **MEB Güvenlik Sertifikası Zorunluluğu (fatihca):**
   - MEB ağında sitelere girerken *"Bağlantınız gizli değil"* (ERR_CERT_AUTHORITY_INVALID) uyarısı alınıyorsa MEB kök sertifikası eksiktir.
   - **FatihBypass Çözümü:** Uygulama içindeki **MEB Sertifikası** sekmesinden tek tıkla resmi `fatihca` sertifikasını Windows'a tanıtabilirsiniz.

4. **Kablolu Ağda IP Alamama / "Tanımlanamayan Ağ" Hatası:**
   - Okul switch'ine ethernet kablosu bağlandığında eski DHCP veya DNS önbelleği nedeniyle sarı ünlem veya bağlantı kopmaları oluşabilir.
   - **FatihBypass Çözümü:** Uygulamadaki **"Kablolu Ağı Onar & IP Yenile"** butonu tek tıkla DNS'i temizler, eski IP'yi bırakır ve okuldan yeni temiz bir IP alır.

---

## 🚀 2. Nasıl Başlatılır?

Uygulamayı başlatmanın 3 kolay yolu vardır:

1. **Masaüstü Kısayolu:**
   - Masaüstünüzdeki **`FatihBypass`** kısayoluna çift tıklayın.
2. **Klasörden Başlatma:**
   - `C:\Users\umut\FatihBypass\Baslat.bat` dosyasına çift tıklayın.
3. **Arka Planda Sessiz Başlatma:**
   - Siyah komut penceresi çıkmadan çalıştırmak için `Sessiz_Baslat.vbs` dosyasına çift tıklayın.

---

## 💻 3. Arayüz Kullanımı ve Adım Adım İşlemler

Uygulama açıldığında:

1. **Bypass'ı Başlatma:**
   - Yeşil **`▶ BYPASS'I BAŞLAT`** butonuna tıklayın.
   - Durum rozeti **`● AKTİF — KORUNUYOR`** rengine döner.
   - Windows Sistem Proxy'si otomatik olarak `127.0.0.1:8085` portuna bağlanır ve tüm tarayıcılar (Thorium, Edge, Chrome), Discord ve istemciler engelsiz internete çıkmaya başlar.
2. **Sertifika Durumu:**
   - Eğer üstte *"MEB Sertifikası: Eksik"* uyarısı görürseniz, **"MEB Sertifikası"** sekmesine geçip **"MEB Sertifikasını Sisteme Yükle"** butonuna basmanız yeterlidir.
3. **Kablo Takınca Ağ Hatası Varsa:**
   - **"Kablolu Ağ Doktoru"** sekmesine gelin ve **"Kablolu Ağı Onar & IP Yenile"** butonuna basın.
4. **Bypass'ı Kapatma:**
   - Kırmızı **`⏹ BYPASS'I DURDUR`** butonuna tıkladığınızda tüm proxy ve tünel ayarları anında sıfırlanır, bilgisayarınız standart ağ ayarlarına döner.

---

## 🎮 4. Oyunlar ve Tam UDP Desteği (Psiphon Modu)

Eğer Roblox, Steam multiplayer gibi doğrudan UDP portu gerektiren veya IP seviyesinde engelli sunuculara sahip oyunlar oynamak isterseniz:
- **"Mod & Ayarlar"** sekmesinden **"Psiphon 3 Portable Tünel"** modunu seçip başlatabilirsiniz.
- Psiphon motoru klasör içinde (`bin/psiphon3.exe`) hazır olarak bulunmaktadır.

---

## 📁 5. Dosya Yapısı

- `Baslat.bat` -> Grafik arayüzü başlatıcı.
- `Durdur.bat` -> Tüm proxy ve tünel ayarlarını sıfırlayıp kapatır.
- `Sertifika_Kur.bat` -> MEB sertifikasını tek tıkla kurar.
- `Agi_Onar.bat` -> Ağ ve IP önbelleğini onarır.
- `bin/ciadpi.exe` -> Donanım hızlandırmalı DPI paket bölücü motor.
- `bin/psiphon3.exe` -> Taşınabilir tam tünel VPN motoru.
- `certs/` -> Resmi MEB kök sertifikaları (CER ve CRT).
