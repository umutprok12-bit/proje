$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("C:\Users\umut\Desktop\FatihBypass.lnk")
$Shortcut.TargetPath = "C:\Users\umut\FatihBypass\Baslat.bat"
$Shortcut.WorkingDirectory = "C:\Users\umut\FatihBypass"
$Shortcut.Description = "FATİH Ağı Kısıtlama Kaldırıcı"
$Shortcut.IconLocation = "shell32.dll,14"
$Shortcut.Save()
