@echo off
title Ag Doktoru ve Onarim
cd /d "%~dp0"

echo ========================================================
echo   KABLOLU / KABLOSUZ AG VE DHCP ONARIMI
echo ========================================================

python cli.py --repair
if %ERRORLEVEL% neq 0 (
    py -3 cli.py --repair
)

echo.
pause
