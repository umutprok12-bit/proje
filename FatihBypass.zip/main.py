"""
FatihBypass - Main Entry Point
MEB FATİH Ağı Kısıtlama Kaldırıcı Ana Başlatıcı
"""

import sys
import os

# Ensure package path is accessible
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

def main():
    if len(sys.argv) > 1 and sys.argv[1].startswith("--"):
        from cli import main as cli_main
        cli_main()
    else:
        from src.gui import launch_gui
        launch_gui()

if __name__ == "__main__":
    main()
