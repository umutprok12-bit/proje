@echo off
title FatihBypass Baslatici
cd /d "%~dp0"

echo ========================================================
echo   FATIH BYPASS - MEB Ag Kisitlama Kaldirici
echo ========================================================
echo Uygulama baslatiliyor, lutfen bekleyin...

where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    start "" pythonw main.py
    exit
)

where py >nul 2>nul
if %ERRORLEVEL% equ 0 (
    start "" py -3 main.py
    exit
)

echo [HATA] Python bulunamadi! Lutfen Python'in kurulu oldugundan emin olun.
pause
