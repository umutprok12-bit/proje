# FATİH BYPASS v1.0

A high-performance Windows network circumvention and optimization suite tailored for MEB FATİH school networks (Ethernet & Wi-Fi) in Turkey.

## Features
- **TLS Record Splitting & SNI Desync**: Evades FortiGate/Huawei DPI firewalls with zero speed penalty.
- **Encrypted DNS (DoH)**: Bypasses UDP 53 hijacking using Cloudflare (1.1.1.1) and Google (8.8.8.8) over HTTPS.
- **Official MEB Root Certificate Manager**: Integrated `fatihca` installer to resolve SSL interception warnings.
- **Ethernet Doctor**: One-click DHCP lease renewal, DNS cache flushing, and ARP table reset.
- **Modern Dark GUI & CLI**: Lightweight Tkinter desktop interface with live bandwidth and connection telemetry.
- **Zero Install Needed**: Fully standalone, runs on Python 3.

## Quick Start
- Launch `Baslat.bat` or the Desktop shortcut `FatihBypass.lnk`.
- Click **▶ BYPASS'I BAŞLAT**.
- To restore default Windows network configuration, click **⏹ BYPASS'I DURDUR** or run `Durdur.bat`.
